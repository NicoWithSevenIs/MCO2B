package com.MCO2B.java;

public class Golden_Weapon extends Bladed_Weapon {
	


	public Golden_Weapon(String param_name, int param_power, int param_level, int param_rarity) {
		super(param_name, param_power, param_level, param_rarity);
	}


}
